﻿using System;
using System.Collections.Generic;

namespace DeckOfCards {
    class Program {
        static void Main (string[] args) {
            Deck thisDeck = new Deck();
            thisDeck.Shuffle();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();
            thisDeck.Deal();

            thisDeck.Deal();
        }
    }
}
