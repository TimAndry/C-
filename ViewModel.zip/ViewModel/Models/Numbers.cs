using System.Collections.Generic;

namespace RazorFun
{
    public class Numbers
    {
        public int[] numbers {get;set;}
    }
}