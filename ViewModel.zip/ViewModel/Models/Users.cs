namespace RazorFun
{
    public class Users
    {
        public string[] users{get; set;}
    }
}