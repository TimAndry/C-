namespace RazorFun
{
    public class Message
    {
        public string message {get;set;}
    }
}