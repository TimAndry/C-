﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using LoginRegistration.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoginRegistration.Controllers {
    public class HomeController : Controller {
        private LRContext _context;
        public HomeController (LRContext context) {
            _context = context;
        }

        [HttpGet]
        [Route ("")]
        public IActionResult Index () {
            return View ("Index");
        }

        public IActionResult Create (User NewUser) {
            List<User> dupe = _context.Users.Where (user => user.Email == NewUser.Email).ToList ();
            if (ModelState.IsValid && NewUser.Password == NewUser.ConfirmPassword && dupe.Count () == 0) {
                PasswordHasher<User> Hasher = new PasswordHasher<User> ();
                NewUser.Password = Hasher.HashPassword (NewUser, NewUser.Password);
                User user = new User {
                    FirstName = NewUser.FirstName,
                    LastName = NewUser.LastName,
                    Email = NewUser.Email,
                    Password = NewUser.Password,
                    ConfirmPassword = NewUser.Password,
                };
                _context.Add (user);
                _context.SaveChanges ();
                System.Console.WriteLine ("****************SUCCESS*******************");
                return RedirectToAction ("Index");
            } else {
                System.Console.WriteLine ("We have errors");
                return View ("Index");
            }
        }

        [HttpGet]
        [Route ("LoginPage")]
        public IActionResult LoginPage () {
            return View ("loginpage");
        }

        public IActionResult Login (User OldUser) {
            System.Console.WriteLine ("*******************" + OldUser.Email + " " + OldUser.Password + "**********************");
            User user = _context.Users.SingleOrDefault (auser => auser.Email == OldUser.Email);
            PasswordHasher<User> Hasher = new PasswordHasher<User> ();
            var result = Hasher.VerifyHashedPassword(user, user.Password, OldUser.Password);
            if (result != 0) {
                System.Console.WriteLine ("Succuess");
                return View ("LoginPage");
            } else {
                System.Console.WriteLine ("Try Again");
                return View ("LoginPage");
            }
        }

    }
}