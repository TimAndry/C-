using System.ComponentModel.DataAnnotations;
namespace QuotingDojo.Models
{
    public class Quote
    {
        
        public string Name {get; set;}

        public string QuoteText{get; set;}   
    }
}