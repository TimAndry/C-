var LineSelect = new Vue({
    el: '#LineSelect',
    data: {
        line: 'All Lines'
    }
})